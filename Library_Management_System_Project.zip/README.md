# Library Management System

## Objective
Develop a Library Management System using Object-Oriented Programming concepts.

## Features
- Add books to the library
- View available books
- View all books
- Issue books
- Return books
- Search books by title or author
- Maintain book availability status

## Book Fields
- Book ID
- Title
- Author
- Category
- Availability Status

## OOP Concepts Used
- Class
- Object
- Constructor
- Methods
- Encapsulation
- List of objects

## How to Run

```bash
python library_management_system.py
```

## Sample Output

```text
Library Management System
1. Add Book
2. View Available Books
3. View All Books
4. Issue Book
5. Return Book
6. Search Book by Title or Author
7. Exit
Enter your choice (1-7): 3
```

```text
Book ID    Title                     Author               Category        Status
B101       Python Basics             John Smith           Programming     Available
B102       Clean Code                Robert Martin        Software        Available
B103       Data Science 101          Jane Wilson          Technology      Available
```

## Files Included
- library_management_system.py
- README.md
- sample_output.txt
