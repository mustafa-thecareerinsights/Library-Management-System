class Book:
    """Represents a single book in the library."""

    def __init__(self, book_id, title, author, category):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.category = category
        self.is_available = True

    def issue_book(self):
        if self.is_available:
            self.is_available = False
            return True
        return False

    def return_book(self):
        if not self.is_available:
            self.is_available = True
            return True
        return False

    def display_book(self):
        status = "Available" if self.is_available else "Issued"
        print(f"{self.book_id:<10} {self.title:<25} {self.author:<20} {self.category:<15} {status:<10}")


class Library:
    """Manages library operations using OOP principles."""

    def __init__(self):
        self.books = []

    def add_book(self):
        book_id = input("Enter Book ID: ").strip()
        title = input("Enter Book Title: ").strip()
        author = input("Enter Author Name: ").strip()
        category = input("Enter Category: ").strip()

        if not book_id or not title or not author or not category:
            print("All fields are required.")
            return

        for book in self.books:
            if book.book_id == book_id:
                print("Book ID already exists.")
                return

        new_book = Book(book_id, title, author, category)
        self.books.append(new_book)
        print("Book added successfully.")

    def view_available_books(self):
        available_books = [book for book in self.books if book.is_available]

        if not available_books:
            print("No available books found.")
            return

        self.display_header()
        for book in available_books:
            book.display_book()

    def view_all_books(self):
        if not self.books:
            print("No books in the library.")
            return

        self.display_header()
        for book in self.books:
            book.display_book()

    def issue_book(self):
        book_id = input("Enter Book ID to issue: ").strip()

        for book in self.books:
            if book.book_id == book_id:
                if book.issue_book():
                    print("Book issued successfully.")
                else:
                    print("Book is already issued.")
                return

        print("Book not found.")

    def return_book(self):
        book_id = input("Enter Book ID to return: ").strip()

        for book in self.books:
            if book.book_id == book_id:
                if book.return_book():
                    print("Book returned successfully.")
                else:
                    print("Book was not issued.")
                return

        print("Book not found.")

    def search_books(self):
        keyword = input("Enter title or author to search: ").strip().lower()

        if not keyword:
            print("Search keyword cannot be empty.")
            return

        results = [
            book for book in self.books
            if keyword in book.title.lower() or keyword in book.author.lower()
        ]

        if not results:
            print("No matching books found.")
            return

        self.display_header()
        for book in results:
            book.display_book()

    @staticmethod
    def display_header():
        print("\n" + "-" * 85)
        print(f"{'Book ID':<10} {'Title':<25} {'Author':<20} {'Category':<15} {'Status':<10}")
        print("-" * 85)


def main():
    library = Library()

    library.books.append(Book("B101", "Python Basics", "John Smith", "Programming"))
    library.books.append(Book("B102", "Clean Code", "Robert Martin", "Software"))
    library.books.append(Book("B103", "Data Science 101", "Jane Wilson", "Technology"))

    while True:
        print("\nLibrary Management System")
        print("1. Add Book")
        print("2. View Available Books")
        print("3. View All Books")
        print("4. Issue Book")
        print("5. Return Book")
        print("6. Search Book by Title or Author")
        print("7. Exit")

        choice = input("Enter your choice (1-7): ").strip()

        if choice == "1":
            library.add_book()
        elif choice == "2":
            library.view_available_books()
        elif choice == "3":
            library.view_all_books()
        elif choice == "4":
            library.issue_book()
        elif choice == "5":
            library.return_book()
        elif choice == "6":
            library.search_books()
        elif choice == "7":
            print("Thank you for using Library Management System.")
            break
        else:
            print("Invalid choice. Please select 1 to 7.")


if __name__ == "__main__":
    main()
